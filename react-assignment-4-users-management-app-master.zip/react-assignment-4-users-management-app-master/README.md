# React assigment - 4 : User Management App

## Total points = 5

### Purpose of this assignment : Testing students skills on

- useEffect() hook
- error handling when loading data

### [Click here to see the project demo](https://users-mgt-app.netlify.app/)

### Assignment steps:

- all the instructtions are given in App component
  - only 3 tasks to do in App component
- finally check the project demo and try to match your one as much as possible

#### [Assignment was created with &hearts; by [anisul islam](https://www.youtube.com/c/anisulislamrubel) &copy;Anisul Islam]
